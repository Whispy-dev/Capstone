@extends('layout.master')
@section('title', 'Crear Nuevo Cargo')

@section('main-content')
<div class="container">
    <h2>Crear Nuevo Cargo</h2>

    @if($errors->any())
        <div class="alert alert-danger">
            <strong>Errores:</strong>
            <ul class="mb-0">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('positions.store') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label for="name" class="form-label">Nombre del Cargo</label>
            <input type="text" name="name" class="form-control" required value="{{ old('name') }}">
        </div>

        <div class="mb-3">
            <label for="level" class="form-label">Nivel</label>
            <input type="text" name="level" class="form-control" value="{{ old('level') }}">
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Descripción</label>
            <textarea name="description" class="form-control">{{ old('description') }}</textarea>
        </div>

        <div class="mb-3">
            <label for="area_id" class="form-label">Área Asociada</label>
            <select name="area_id" class="form-select" required>
                <option value="">Seleccione un área</option>
                @foreach($areas as $area)
                    <option value="{{ $area->id }}" {{ old('area_id') == $area->id ? 'selected' : '' }}>
                        {{ $area->name }}
                    </option>
                @endforeach
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Guardar Cargo</button>
        <a href="{{ route('positions.index') }}" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
@endsection


