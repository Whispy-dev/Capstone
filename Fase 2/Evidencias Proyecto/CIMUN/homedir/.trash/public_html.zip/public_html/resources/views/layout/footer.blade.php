

<!-- Footer Section starts-->
<footer>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-9 col-12">
                <p class="footer-text f-w-600 mb-0">Copyright © 2025 BROUTER®. Todos los derechos reservados 💖 V1.0.0</p>
            </div>
            <div class="col-md-3">
                <div class="footer-text text-end">
                    <a class="f-w-500 text-primary" href="mailto:teqlathemes@gmail.com"> Necesitas ayuda? <i
                            class="ti ti-help"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Section ends-->
