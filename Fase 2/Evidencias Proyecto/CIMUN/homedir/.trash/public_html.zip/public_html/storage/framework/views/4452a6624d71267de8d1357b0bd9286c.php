<!DOCTYPE html>
<html lang="en">
<?php $__env->startSection('title', 'Maintenance'); ?>
<?php echo $__env->make('layout.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('layout.css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body>

<!-- maintenance start -->
<div class="bg-light-primary maintenance py-5">
    <div class="container">
        <div class="overlay-maintenance-card text-center">
            <img alt="" class="img-fluid" src="../assets/images/pages/objects.png">

            <h1 class="text-dark f-w-600 mt-4"> We are <br>under Maintenance</h1>
            <p class=" text-secondary">Someone has kidnapped our site. We are negotiation ransom and
                will resolve this issue in 24/7 hours</p>
            <a class="btn btn-lg btn-danger mt-3 b-r-22" href="<?php echo e(route('index')); ?>" role="button">
                <i class="ti ti-home"></i>
                Back To Home </a>

        </div>
    </div>
</div>
<!-- maintenance end -->

</body>
    <!-- Bootstrap js-->
    <script src="<?php echo e(asset('assets/vendor/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
</html>
<?php /**PATH /home/cimun/public_html/resources/views/maintenance.blade.php ENDPATH**/ ?>