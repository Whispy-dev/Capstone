<?php $__env->startSection('title', 'Scatter Chart'); ?>
<?php $__env->startSection('css'); ?>
    <!-- apexcharts css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/apexcharts/apexcharts.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <!-- Breadcrumb start -->
        <div class="row m-1">
            <div class="col-12 ">
                <h4 class="main-title">Scatter</h4>
                <ul class="app-line-breadcrumbs mb-3">
                    <li class="">
                        <a href="#" class="f-s-14 f-w-500">
                      <span>
                        <i class="ph-duotone  ph-chart-pie-slice f-s-16"></i> Chart
                      </span>
                        </a>
                    </li>
                    <li class="">
                        <a href="#" class="f-s-14 f-w-500">
                      <span>
                        Apexcharts
                      </span>
                        </a>
                    </li>
                    <li class="active">
                        <a href="#" class="f-s-14 f-w-500">Scatter</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Breadcrumb end -->
        <div class="row">
            <!-- Scatter (XY) Chart start -->
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5> Scatter (XY) Chart</h5>
                    </div>
                    <div class="card-body">
                        <div id="scatter1"></div>
                    </div>
                </div>
            </div>
            <!-- Scatter (XY) Chart end -->

            <!-- Scatter – Image fill start -->
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5> Scatter – Image fill</h5>
                    </div>
                    <div class="card-body">
                        <div id="scatter3"></div>
                    </div>
                </div>
            </div>
            <!-- Scatter – Image fill end -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<!-- apexcharts-->
<script src="<?php echo e(asset('assets/vendor/apexcharts/apexcharts.min.js')); ?>"></script>

<!-- js-->
<script src="<?php echo e(asset('assets/js/scatter.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/scatter_chart.blade.php ENDPATH**/ ?>