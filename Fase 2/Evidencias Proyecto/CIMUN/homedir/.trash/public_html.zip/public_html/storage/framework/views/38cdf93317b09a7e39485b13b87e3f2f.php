<meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
<meta content="IE=edge" http-equiv="X-UA-Compatible">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content="Multipurpose, super flexible, powerful, clean modern responsive bootstrap 5 admin template"
      name="description">
<meta content="admin template, ki-admin admin template, dashboard template, flat admin template, responsive admin template, web app"
      name="keywords">
<meta content="la-themes" name="author">

<link rel="icon" href="<?php echo e(('../assets/images/logo/favicon.png')); ?>" type="image/x-icon">
<link rel="shortcut icon" href="<?php echo e(('../assets/images/logo/favicon.png')); ?>" type="image/x-icon">

<title><?php echo $__env->yieldContent('title'); ?> | CIMUN - Centro de Incidencias Municipales</title>
<?php /**PATH /home/cimun/public_html/resources/views/layout/head.blade.php ENDPATH**/ ?>