<?php $__env->startSection('title', 'Calendario'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/slick/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/slick/slick-theme.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <!-- Breadcrumb inicio -->
        <div class="row m-1">
            <div class="col-12 ">
                <h4 class="main-title">Calendario</h4>
                <ul class="app-line-breadcrumbs mb-3">
                    <li class="">
                        <a href="#" class="f-s-14 f-w-500">
                      <span>
                        <i class="ph-duotone ph-stack f-s-16"></i> Aplicaciones
                      </span>
                        </a>
                    </li>
                    <li class="active">
                        <a href="#" class="f-s-14 f-w-500">Calendario</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Breadcrumb fin -->

        <!-- Mensajes de éxito/error -->
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row m-1 calendar app-fullcalender">
            <!-- Panel lateral inicio -->
            <div class="col-xxl-3">
                <div class="row">
                    <!-- Botón crear evento -->
                    <div class="col-md-6 col-xxl-12">
                        <div class="card mb-3">
                            <div class="card-body text-center">
                                <a href="<?php echo e(route('events.create')); ?>" class="btn btn-primary btn-lg w-100">
                                    <i class="ti ti-plus me-2"></i>Crear Evento
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Eventos Arrastrables -->
                    <div class="col-md-6 col-xxl-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>Tipos de Eventos</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <div class="d-flex align-items-center mb-2">
                                        <div class="badge bg-primary me-2" style="width: 15px; height: 15px;"></div>
                                        <span>Reunión Interna</span>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <div class="badge bg-success me-2" style="width: 15px; height: 15px;"></div>
                                        <span>Reunión Externa</span>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <div class="badge bg-danger me-2" style="width: 15px; height: 15px;"></div>
                                        <span>Incidente</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Lista de próximos eventos -->
                    <div class="col-md-6 col-xxl-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>Próximos Eventos</h5>
                            </div>
                            <div class="card-body">
                                <div class="event-container">
                                    <?php $__empty_1 = true; $__currentLoopData = $events->where('start', '>=', now())->sortBy('start')->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="event-box mb-3 p-2 border rounded">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1">
                                                        <span class="badge bg-<?php echo e($event->type === 'interna' ? 'primary' : ($event->type === 'externa' ? 'success' : 'danger')); ?> me-1"></span>
                                                        <?php echo e($event->title); ?>

                                                    </h6>
                                                    <?php if($event->description): ?>
                                                        <p class="mb-1 text-secondary f-s-13"><?php echo e(Str::limit($event->description, 50)); ?></p>
                                                    <?php endif; ?>
                                                    <p class="f-s-13 text-muted mb-0">
                                                        <i class="ti ti-calendar-event me-1"></i><?php echo e($event->start->format('d/m/Y H:i')); ?>

                                                    </p>
                                                </div>
                                                <div class="dropdown">
                                                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                                        <i class="ti ti-dots-vertical"></i>
                                                    </button>
                                                    <ul class="dropdown-menu">
                                                        <li><a class="dropdown-item" href="<?php echo e(route('events.show', $event->id)); ?>">Ver</a></li>
                                                        <li><a class="dropdown-item" href="<?php echo e(route('events.edit', $event->id)); ?>">Editar</a></li>
                                                        <li><hr class="dropdown-divider"></li>
                                                        <li>
                                                            <form action="<?php echo e(route('events.destroy', $event->id)); ?>" method="POST" class="d-inline">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="dropdown-item text-danger" 
                                                                        onclick="return confirm('¿Estás seguro?')">Eliminar</button>
                                                            </form>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <p class="text-muted text-center">No hay eventos próximos</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Panel lateral fin -->

            <!-- Calendario principal -->
            <div class="col-xxl-9">
                <div class="card">
                    <div class="card-header">
                        <h5>Calendario de Eventos</h5>
                    </div>
                    <div class="card-body">
                        <!-- Vista de calendario básica -->
                        <div class="calendar-basic">
                            <div class="row">
                                <!-- Controles del calendario -->
                                <div class="col-12 mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h4 id="currentMonth"><?php echo e(now()->format('F Y')); ?></h4>
                                        <div>
                                            <button class="btn btn-outline-primary btn-sm me-1" onclick="previousMonth()">
                                                <i class="ti ti-chevron-left"></i>
                                            </button>
                                            <button class="btn btn-outline-primary btn-sm me-1" onclick="nextMonth()">
                                                <i class="ti ti-chevron-right"></i>
                                            </button>
                                            <button class="btn btn-primary btn-sm" onclick="goToday()">Hoy</button>
                                        </div>
                                    </div>
                                </div>

                                <!-- Grid del calendario -->
                                <div class="col-12">
                                    <div class="table-responsive">
                                        <table class="table table-bordered calendar-table">
                                            <thead>
                                                <tr>
                                                    <th class="text-center">Dom</th>
                                                    <th class="text-center">Lun</th>
                                                    <th class="text-center">Mar</th>
                                                    <th class="text-center">Mié</th>
                                                    <th class="text-center">Jue</th>
                                                    <th class="text-center">Vie</th>
                                                    <th class="text-center">Sáb</th>
                                                </tr>
                                            </thead>
                                            <tbody id="calendar-body">
                                                <?php
                                                    $currentDate = now();
                                                    $firstDay = $currentDate->copy()->startOfMonth();
                                                    $lastDay = $currentDate->copy()->endOfMonth();
                                                    $startCalendar = $firstDay->copy()->startOfWeek(0);
                                                    $endCalendar = $lastDay->copy()->endOfWeek(6);
                                                    
                                                    $weeks = [];
                                                    $current = $startCalendar->copy();
                                                    
                                                    while ($current->lte($endCalendar)) {
                                                        $week = [];
                                                        for ($i = 0; $i < 7; $i++) {
                                                            $dayEvents = $events->filter(function ($event) use ($current) {
                                                                return $event->start->format('Y-m-d') === $current->format('Y-m-d');
                                                            });
                                                            
                                                            $week[] = [
                                                                'date' => $current->copy(),
                                                                'events' => $dayEvents,
                                                                'isCurrentMonth' => $current->month === $firstDay->month
                                                            ];
                                                            $current->addDay();
                                                        }
                                                        $weeks[] = $week;
                                                    }
                                                ?>

                                                <?php $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td class="calendar-day <?php echo e($day['isCurrentMonth'] ? '' : 'text-muted'); ?>" 
                                                                style="height: 120px; vertical-align: top; position: relative;">
                                                                <div class="d-flex justify-content-between align-items-start">
                                                                    <span class="day-number <?php echo e($day['date']->isToday() ? 'bg-primary text-white rounded px-1' : ''); ?>">
                                                                        <?php echo e($day['date']->day); ?>

                                                                    </span>
                                                                    <?php if($day['isCurrentMonth']): ?>
                                                                        <a href="<?php echo e(route('events.create', ['date' => $day['date']->format('Y-m-d')])); ?>" 
                                                                           class="btn btn-sm btn-outline-primary" style="font-size: 10px; padding: 2px 4px;">
                                                                            <i class="ti ti-plus"></i>
                                                                        </a>
                                                                    <?php endif; ?>
                                                                </div>
                                                                
                                                                <div class="events-list mt-1">
                                                                    <?php $__currentLoopData = $day['events']->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <div class="event-item mb-1">
                                                                            <a href="<?php echo e(route('events.show', $event->id)); ?>" 
                                                                               class="badge bg-<?php echo e($event->type === 'interna' ? 'primary' : ($event->type === 'externa' ? 'success' : 'danger')); ?> text-decoration-none d-block text-truncate" 
                                                                               style="font-size: 9px; max-width: 100%;" 
                                                                               title="<?php echo e($event->title); ?> - <?php echo e($event->start->format('H:i')); ?>">
                                                                                <?php echo e(Str::limit($event->title, 15)); ?>

                                                                            </a>
                                                                        </div>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    
                                                                    <?php if($day['events']->count() > 3): ?>
                                                                        <small class="text-muted">+<?php echo e($day['events']->count() - 3); ?> más</small>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .calendar-table td {
            width: 14.28%;
            min-height: 120px;
        }
        
        .day-number {
            font-weight: 500;
            font-size: 14px;
        }
        
        .event-item {
            font-size: 10px;
        }
        
        .calendar-day:hover {
            background-color: #f8f9fa;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- slick-file -->
    <script src="<?php echo e(asset('assets/vendor/slick/slick.min.js')); ?>"></script>
    
    <script>
        // Funciones básicas para navegación del calendario (opcional)
        function previousMonth() {
            // Implementar navegación anterior
            window.location.href = "<?php echo e(route('calendar.index')); ?>?month=" + (new Date().getMonth());
        }
        
        function nextMonth() {
            // Implementar navegación siguiente
            window.location.href = "<?php echo e(route('calendar.index')); ?>?month=" + (new Date().getMonth() + 2);
        }
        
        function goToday() {
            window.location.href = "<?php echo e(route('calendar.index')); ?>";
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/calendar/calendar.blade.php ENDPATH**/ ?>