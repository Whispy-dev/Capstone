<!DOCTYPE html>
<html lang="en">
<?php $__env->startSection('title', 'Forbidden'); ?>
<?php echo $__env->make('layout.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('layout.css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="error-container p-0">
    <div class="container">
        <div>
            <div>
                <img src="<?php echo e(asset('../assets/images/background/error-403.png')); ?>" class="img-fluid" alt="">
            </div>
            <div class="mb-3">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <p class="text-center text-secondary f-w-500">403 Forbidden response status code indicates that the server
                            understands the request<br> but refuses to authorize it.</p>
                    </div>
                </div>
            </div>
            <a role="button" href="<?php echo e(route('index')); ?>" class="btn btn-lg btn-success"><i class="ti ti-home"></i> Back To Home</a>
        </div>
    </div>
</div>
    <!--jquery-->
    <script src="<?php echo e(asset('assets/js/jquery-3.6.3.min.js')); ?>"></script>

    <!-- Bootstrap js-->
    <script src="<?php echo e(asset('assets/vendor/bootstrap/bootstrap.bundle.min.js')); ?>"></script>

</html>
<?php /**PATH /home/cimun/public_html/resources/views/error_403.blade.php ENDPATH**/ ?>