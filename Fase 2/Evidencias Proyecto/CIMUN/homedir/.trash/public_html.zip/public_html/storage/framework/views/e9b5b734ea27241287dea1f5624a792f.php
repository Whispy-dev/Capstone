<?php $__env->startSection('title', 'Detalles del Incidente'); ?>

<?php $__env->startSection('main-content'); ?>
<div class="container">
    <h2>Asignar Cargo a Usuario</h2>

    <form action="<?php echo e(route('positions.assignToUser')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="user_id" class="form-label">Usuario</label>
            <select name="user_id" class="form-select" required>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> (<?php echo e($user->email); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="position_id" class="form-label">Cargo</label>
            <select name="position_id" class="form-select" required>
                <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($position->id); ?>"><?php echo e($position->name); ?> - <?php echo e($position->area->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="assigned_at" class="form-label">Fecha de Asignación</label>
            <input type="date" name="assigned_at" class="form-control" required value="<?php echo e(now()->toDateString()); ?>">
        </div>

        <button type="submit" class="btn btn-success">Asignar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/positions/assign.blade.php ENDPATH**/ ?>