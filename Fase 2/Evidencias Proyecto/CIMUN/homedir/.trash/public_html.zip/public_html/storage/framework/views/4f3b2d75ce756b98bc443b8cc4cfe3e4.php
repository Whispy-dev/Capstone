
<?php $__env->startSection('title', 'Panel de Control'); ?>
<?php $__env->startSection('css'); ?>
    <!-- Bootstrap CSS ya incluido en master -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <!-- Alerta de Bienvenida -->
        <div class="row mt-3">
            <div class="col-12">
                <div class="alert alert-primary alert-dismissible" role="alert">
                    <div class="d-flex justify-content-between align-items-center">
                        <p class="mb-0">
                            <i class="ti ti-info-circle me-2"></i>
                            ¡Bienvenido al Panel de Control! Aquí puedes monitorear todos tus incidentes y actividades.
                        </p>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Columna Principal Izquierda -->
            <div class="col-lg-8">
                <!-- Resumen de Incidentes -->
                <div class="row mb-4">
                    <div class="col-md-4 mb-3">
                        <div class="card overview-details-box b-s-3-primary">
                            <div class="card-body">
                                <div class="d-flex gap-3 align-items-center mb-3">
                                    <span class="bg-primary h-60 w-60 d-flex-center flex-column rounded-3 text-white">
                                        <span class="f-w-500">Inc</span>
                                        <span><?php echo e($incidentesAbiertos); ?></span>
                                    </span>
                                    <div>
                                        <p class="text-dark f-w-600 txt-ellipsis-1">Incidentes Abiertos</p>
                                        <span class="badge bg-primary b-r-50">
                                            Total: <?php echo e($incidentesAbiertos); ?>

                                        </span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <p class="text-dark f-w-500 txt-ellipsis-1 mb-1">Estado</p>
                                        <h6 class="mb-0 text-primary">Activos</h6>
                                    </div>
                                    <div class="col-6">
                                        <p class="text-dark f-w-500 txt-ellipsis-1 mb-1">Prioridad</p>
                                        <h6 class="mb-0 text-primary">Alta</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 mb-3">
                        <div class="card overview-details-box b-s-3-success">
                            <div class="card-body">
                                <div class="d-flex gap-3 align-items-center mb-3">
                                    <span class="bg-success h-60 w-60 d-flex-center flex-column rounded-3 text-white">
                                        <span class="f-w-500">Res</span>
                                        <span><?php echo e($incidentesResueltos); ?></span>
                                    </span>
                                    <div>
                                        <p class="text-dark f-w-600 txt-ellipsis-1">Incidentes Resueltos</p>
                                        <span class="badge bg-success b-r-50">
                                            Total: <?php echo e($incidentesResueltos); ?>

                                        </span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <p class="text-dark f-w-500 txt-ellipsis-1 mb-1">Tiempo Promedio</p>
                                        <h6 class="mb-0 text-success">
                                            <?php echo e($tiempoPromedioResolucion ? round($tiempoPromedioResolucion) . 'min' : 'N/A'); ?>

                                        </h6>
                                    </div>
                                    <div class="col-6">
                                        <p class="text-dark f-w-500 txt-ellipsis-1 mb-1">Eficiencia</p>
                                        <h6 class="mb-0 text-success"><?php echo e($incidentesResueltos > 0 ? round(($incidentesResueltos / ($incidentesAbiertos + $incidentesResueltos + $incidentesPendientes)) * 100) . '%' : '0%'); ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 mb-3">
                        <div class="card overview-details-box b-s-3-warning">
                            <div class="card-body">
                                <div class="d-flex gap-3 align-items-center mb-3">
                                    <span class="bg-warning h-60 w-60 d-flex-center flex-column rounded-3 text-dark">
                                        <span class="f-w-500">Pen</span>
                                        <span><?php echo e($incidentesPendientes); ?></span>
                                    </span>
                                    <div>
                                        <p class="text-dark f-w-600 txt-ellipsis-1">Incidentes Pendientes</p>
                                        <span class="badge bg-warning b-r-50">
                                            Total: <?php echo e($incidentesPendientes); ?>

                                        </span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <p class="text-dark f-w-500 txt-ellipsis-1 mb-1">En Revisión</p>
                                        <h6 class="mb-0 text-warning"><?php echo e($incidentesPendientes); ?></h6>
                                    </div>
                                    <div class="col-6">
                                        <p class="text-dark f-w-500 txt-ellipsis-1 mb-1">Esperando</p>
                                        <h6 class="mb-0 text-warning">Respuesta</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Segunda Fila - Gráficos y Estadísticas -->
                <div class="row">
                    <!-- Incidentes por Prioridad -->
                    <div class="col-md-8 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h6 class="mb-0">Incidentes por Prioridad</h6>
                                </div>
                                <div class="row">
                                    <?php $__empty_1 = true; $__currentLoopData = $incidentesPorTipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="col-sm-4 mb-3">
                                        <div class="project-status-card 
                                            <?php if(in_array(strtolower($tipo->priority), ['high', 'alta', 'crítica', 'critica'])): ?> bg-danger 
                                            <?php elseif(in_array(strtolower($tipo->priority), ['medium', 'media', 'normal'])): ?> bg-warning 
                                            <?php else: ?> bg-success <?php endif; ?> 
                                            text-center w-100 rounded p-3 shadow">
                                            <span class="bg-white h-45 w-45 d-flex-center b-r-50 status-icon">
                                                <i class="ti ti-alert-triangle f-s-20 
                                                    <?php if(in_array(strtolower($tipo->priority), ['high', 'alta', 'crítica', 'critica'])): ?> text-danger 
                                                    <?php elseif(in_array(strtolower($tipo->priority), ['medium', 'media', 'normal'])): ?> text-warning 
                                                    <?php else: ?> text-success <?php endif; ?>"></i>
                                            </span>
                                            <p class="text-white mb-0 txt-ellipsis-1 mt-2">
                                                <?php echo e($tipo->priority ? ucfirst($tipo->priority) : 'Sin prioridad'); ?>

                                            </p>
                                            <h4 class="text-white"><?php echo e($tipo->total); ?></h4>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="col-12 text-center">
                                        <p class="text-muted">No hay datos de prioridad disponibles</p>
                                    </div>
                                    <?php endif; ?>
                                </div>

                                <div class="mt-4">
                                    <h6>Resumen de Actividades</h6>
                                    <ul class="list-unstyled">
                                        <li class="d-flex align-items-center justify-content-between mb-2">
                                            <div class="d-flex align-items-center">
                                                <div class="bg-primary-200 d-flex-center p-1 w-30 h-30 b-r-8 flex-shrink-0">
                                                    <i class="ti ti-plus text-primary"></i>
                                                </div>
                                                <p class="text-dark-800 mb-0 f-w-500 f-s-15 txt-ellipsis-1 ms-2">Nuevos Incidentes Hoy</p>
                                            </div>
                                            <span class="badge bg-primary"><?php echo e($incidentesAbiertos); ?></span>
                                        </li>
                                        <li class="d-flex align-items-center justify-content-between mb-2">
                                            <div class="d-flex align-items-center">
                                                <div class="bg-success-200 d-flex-center p-1 w-30 h-30 b-r-8 flex-shrink-0">
                                                    <i class="ti ti-check text-success"></i>
                                                </div>
                                                <p class="text-dark-800 mb-0 f-w-500 f-s-15 txt-ellipsis-1 ms-2">Resueltos Esta Semana</p>
                                            </div>
                                            <span class="badge bg-success"><?php echo e($incidentesResueltos); ?></span>
                                        </li>
                                        <li class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-center">
                                                <div class="bg-warning-200 d-flex-center p-1 w-30 h-30 b-r-8 flex-shrink-0">
                                                    <i class="ti ti-clock text-warning"></i>
                                                </div>
                                                <p class="text-dark-800 mb-0 f-w-500 f-s-15 txt-ellipsis-1 ms-2">En Proceso</p>
                                            </div>
                                            <span class="badge bg-warning"><?php echo e($incidentesPendientes); ?></span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Estadísticas Generales -->
                    <div class="col-md-4 mb-4">
                        <div class="row">
                            <div class="col-12 mb-3">
                                <div class="card project-profit-card">
                                    <div class="card-body">
                                        <div class="profit-arrow">
                                            <span class="bg-white text-primary h-45 w-45 d-flex-center">
                                                <i class="ti ti-trending-up f-s-18"></i>
                                            </span>
                                        </div>
                                        <span class="bg-primary h-45 w-45 d-flex-center b-r-50">
                                            <i class="ti ti-chart-line f-s-24"></i>
                                        </span>
                                        <div class="mt-3">
                                            <h4 class="text-dark"><?php echo e($incidentesResueltos + $incidentesAbiertos + $incidentesPendientes); ?></h4>
                                            <p class="f-w-500 mb-0 txt-ellipsis-1">Total de Incidentes</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="card bg-primary">
                                    <div class="card-body">
                                        <i class="ti ti-clock icon-bg"></i>
                                        <span class="bg-white h-50 w-50 d-flex-center b-r-50">
                                            <i class="ti ti-clock text-primary f-s-24"></i>
                                        </span>
                                        <div class="mt-3">
                                            <h4 class="text-white"><?php echo e(round($tiempoPromedioResolucion ?? 0)); ?></h4>
                                            <p class="f-w-500 mb-0 txt-ellipsis-1 text-white">Minutos Promedio</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Columna Lateral Derecha -->
            <div class="col-lg-4">
                <!-- Próximas Reuniones -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="mb-3">Próximas Reuniones</h5>
                        <?php if($proximasReuniones->count() > 0): ?>
                            <?php $__currentLoopData = $proximasReuniones->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reunion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="meeting-details-box d-flex align-items-center mb-3">
                                <div class="h-40 w-40 d-flex-center b-r-50 overflow-hidden bg-primary text-white flex-shrink-0">
                                    <?php echo e(substr($reunion->title, 0, 2)); ?>

                                </div>
                                <div class="flex-grow-1 ps-2 text-start">
                                    <div class="fw-medium txt-ellipsis-1"><?php echo e($reunion->title); ?></div>
                                    <div class="text-muted f-s-12 txt-ellipsis-1">
                                        <?php echo e(\Carbon\Carbon::parse($reunion->start)->format('d/m/Y H:i')); ?>

                                    </div>
                                </div>
                                <span class="badge bg-primary">Programada</span>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="text-center text-muted">
                                <p>No hay reuniones programadas</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Distribución por Áreas -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 class="mb-0 txt-ellipsis-1">Incidentes por Área</h6>
                        </div>
                        <div>
                            <?php $__empty_1 = true; $__currentLoopData = $incidentesPorArea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="d-flex align-items-center justify-content-between mb-3">
                                <p class="mb-0 txt-ellipsis-1">
                                    <i class="ti ti-circle-filled text-primary f-s-10"></i> 
                                    <?php echo e($area->user->name ?? 'Usuario ' . $area->user_id); ?>

                                </p>
                                <p class="text-secondary txt-ellipsis-1 mb-0 flex-grow-1 mx-2"> 
                                    ------------------------ 
                                </p>
                                <span><?php echo e($area->total); ?></span>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center text-muted">
                                <p>No hay datos por área disponibles</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Acciones Rápidas -->
                <div class="card">
                    <div class="card-body">
                        <h6 class="mb-3 text-center">Acciones Rápidas</h6>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <button type="button" class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#incidentModal">
                                    <i class="ti ti-plus mb-2"></i><br>
                                    Nuevo Incidente
                                </button>
                            </div>
                            <div class="col-6 mb-3">
                                <a href="<?php echo e(route('incidents.index') ?? '#'); ?>" class="btn btn-success w-100">
                                    <i class="ti ti-list mb-2"></i><br>
                                    Ver Incidentes
                                </a>
                            </div>
                            <div class="col-6">
                                <a href="<?php echo e(route('events.create') ?? '#'); ?>" class="btn btn-info w-100">
                                    <i class="ti ti-calendar mb-2"></i><br>
                                    Nueva Reunión
                                </a>
                            </div>
                            <div class="col-6">
                                <a href="" class="btn btn-warning w-100">
                                    <i class="ti ti-chart-bar mb-2"></i><br>
                                    Reportes
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal para crear incidente -->
        <div class="modal fade" id="incidentModal" tabindex="-1" aria-labelledby="incidentModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?php echo e(route('incidents.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <h5 class="modal-title" id="incidentModalLabel">Nueva Incidencia</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="title" class="form-label">Título</label>
                                <input type="text" name="title" id="title" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">Descripción</label>
                                <textarea name="description" id="description" class="form-control" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="status" class="form-label">Estado</label>
                                <select name="status" id="status" class="form-control">
                                    <option value="open">Abierto</option>
                                    <option value="pending">Pendiente</option>
                                    <option value="resuelto">Resuelto</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="priority" class="form-label">Prioridad</label>
                                <select name="priority" id="priority" class="form-control">
                                    <option value="low">Baja</option>
                                    <option value="medium">Media</option>
                                    <option value="high">Alta</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">Crear Incidencia</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Bootstrap JS ya incluido en master -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/dashboard/index.blade.php ENDPATH**/ ?>