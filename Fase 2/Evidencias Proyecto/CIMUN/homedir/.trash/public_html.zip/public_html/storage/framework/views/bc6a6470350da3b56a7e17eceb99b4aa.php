<?php $__env->startSection('title', 'Cargos cargo a '.$user->name); ?>

<?php $__env->startSection('main-content'); ?>
<div class="container">
    <h2>Asignar cargo a <?php echo e($user->name); ?></h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Ups...</strong> Hay problemas con los datos ingresados:
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('positions.assignToUser', $user->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="position_id" class="form-label">Cargo</label>
            <select name="position_id" id="position_id" class="form-select" required>
                <option value="">Seleccione un cargo</option>
                <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($position->id); ?>">
                        <?php echo e($position->name); ?> (<?php echo e($position->area->name ?? 'Sin área'); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="assigned_at" class="form-label">Fecha de asignación</label>
            <input type="date" name="assigned_at" id="assigned_at" class="form-control" value="<?php echo e(now()->toDateString()); ?>">
        </div>

        <button type="submit" class="btn btn-success">Asignar cargo</button>
        <a href="<?php echo e(route('users.positions', $user->id)); ?>" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/users/assign_position.blade.php ENDPATH**/ ?>