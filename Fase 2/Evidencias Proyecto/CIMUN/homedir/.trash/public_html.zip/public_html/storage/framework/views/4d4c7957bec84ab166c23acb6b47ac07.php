<?php $__env->startSection('title', 'Listado de usuarios'); ?>

<?php $__env->startSection('main-content'); ?>
<div class="container">
    <h2>Listado de usuarios</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-hover">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Email</th>
                <th>Cargos activos</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <?php
                            $activePositions = $user->positions->filter(fn($p) => !$p->pivot->ended_at);
                        ?>
                        <?php if($activePositions->count()): ?>
                            <ul class="list-unstyled mb-0">
                                <?php $__currentLoopData = $activePositions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($position->name); ?> (<?php echo e($position->area->name ?? '—'); ?>)</li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <span class="text-muted">Sin cargos activos</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('users.positions', $user->id)); ?>" class="btn btn-sm btn-primary">Ver cargos</a>
                        <a href="<?php echo e(route('positions.assignToUserForm', $user->id)); ?>" class="btn btn-sm btn-success">Asignar cargo</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    
    <?php echo e($users->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/users/index.blade.php ENDPATH**/ ?>