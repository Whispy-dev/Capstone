<!-- Animation css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/animation/animate.min.css')); ?>" >

<!-- Fonts -->
<link href="https://fonts.googleapis.com" rel="preconnect">
<link crossorigin href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300..900;1,300..900&display=swap"
      rel="stylesheet">

<!--Flag Icon css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/flag-icons-master/flag-icon.css')); ?>">

<!-- Tabler icons-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/tabler-icons/tabler-icons.css')); ?>">

<!-- Prism css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/prism/prism.min.css')); ?>">

<!-- Bootstrap css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/bootstrap/bootstrap.min.css')); ?>">

<!-- Simplebar css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/simplebar/simplebar.css')); ?>">

<?php echo $__env->yieldContent('css'); ?>

<?php echo app('Illuminate\Foundation\Vite')(['public/assets/scss/style.scss']); ?>
<?php /**PATH /home/cimun/public_html/resources/views/layout/css.blade.php ENDPATH**/ ?>