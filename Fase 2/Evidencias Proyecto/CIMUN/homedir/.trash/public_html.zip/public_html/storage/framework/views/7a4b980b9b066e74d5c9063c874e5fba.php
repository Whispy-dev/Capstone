
<?php $__env->startSection('title', 'Configuración'); ?>
<?php $__env->startSection('css'); ?>
    <!-- glight css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/glightbox/glightbox.min.css')); ?>">

    <!-- apexcharts css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/apexcharts/apexcharts.css')); ?>">

    <!-- Select2 css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/select/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
<div class="container-fluid">
    <!-- Breadcrumb start -->
    <div class="row m-1">
        <div class="col-12">
            <h4 class="main-title">Configuración</h4>
            <ul class="app-line-breadcrumbs mb-3">
                <li>
                    <a href="#" class="f-s-14 f-w-500">
                        <span><i class="ph-duotone ph-stack f-s-16"></i> Aplicaciones</span>
                    </a>
                </li>
                <li>
                    <a href="#" class="f-s-14 f-w-500">Perfil</a>
                </li>
                <li class="active">
                    <a href="#" class="f-s-14 f-w-500">Configuración</a>
                </li>
            </ul>
        </div>
    </div>
    <!-- Breadcrumb end -->

    <!-- setting-app start -->
    <div class="row">
        <div class="col-lg-8 col-xxl-9">
            <div class="tab-content">
                
                <!-- Información del Perfil -->
                <div class="tab-pane fade active show" id="profile-tab-pane" role="tabpanel"
                     aria-labelledby="profile-tab" tabindex="0">
                    <div class="card setting-profile-tab mb-4">
                        <div class="card-header">
                            <h5>Información del Perfil</h5>
                        </div>
                        <div class="card-body">
                            <div class="profile-tab profile-container">
                                
                                <!-- Avatar / Profile Picture -->
                                <div class="image-details mb-4">
                                    <div class="profile-image"></div>
                                    <div class="profile-pic">
                                        <div class="avatar-upload">
                                            <div class="avatar-edit">
                                                <input type="file" id="imageUpload" accept=".png, .jpg, .jpeg">
                                                <label for="imageUpload"><i class="ti ti-photo-heart"></i></label>
                                            </div>
                                            <div class="avatar-preview">
                                                <div id="imgPreview"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Person Details -->
                                <div class="person-details mb-4">
                                    <h5 class="f-w-600"><?php echo e(Auth::user()->name ?? 'Nombre de Usuario'); ?>

                                        <img width="20" height="20" src="<?php echo e(asset('assets/images/profile-app/01.png')); ?>" alt="marca-verificacion">
                                    </h5>
                                    <p><?php echo e(Auth::user()->role ?? 'Diseñador Web y Desarrollador'); ?></p>
                                </div>

                                <!-- Formulario de Información del Perfil -->
                                <div class="profile-form-section">
                                    <?php echo $__env->make('profile.partials.update-profile-information-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <!-- Actualizar Contraseña -->
                <div class="card setting-profile-tab mb-4">
                    <div class="card-header">
                        <h5>Actualizar Contraseña</h5>
                    </div>
                    <div class="card-body">
                        <div class="profile-tab profile-container">
                            <?php echo $__env->make('profile.partials.update-password-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    </div>
                </div>

                <!-- Eliminar Cuenta -->
                <div class="card setting-profile-tab">
                    <div class="card-header">
                        <h5>Eliminar Cuenta</h5>
                    </div>
                    <div class="card-body">
                        <div class="profile-tab profile-container">
                            <?php echo $__env->make('profile.partials.delete-user-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!--setting app end -->
</div>

<style>
    /* Estilos adicionales para mejorar la apariencia */
    .profile-form-section {
        margin-top: 1rem;
    }
    
    .setting-profile-tab .card-body {
        padding: 1.5rem;
    }
    
    .profile-container {
        width: 100%;
    }
    
    .space-y-6 > * + * {
        margin-top: 1.5rem;
    }
    
    /* Estilos para que los formularios de Laravel se vean bien */
    .profile-tab .form-group,
    .profile-tab .mb-3 {
        margin-bottom: 1rem;
    }
    
    .profile-tab label {
        font-weight: 500;
        margin-bottom: 0.5rem;
        display: block;
    }
    
    .profile-tab input[type="text"],
    .profile-tab input[type="email"],
    .profile-tab input[type="password"] {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid #ddd;
        border-radius: 0.375rem;
        font-size: 0.875rem;
    }
    
    .profile-tab .btn {
        padding: 0.75rem 1.5rem;
        font-size: 0.875rem;
        font-weight: 500;
        border-radius: 0.375rem;
        border: none;
        cursor: pointer;
    }
    
    .profile-tab .btn-primary {
        background-color: #3b82f6;
        color: white;
    }
    
    .profile-tab .btn-danger {
        background-color: #ef4444;
        color: white;
    }
    
    .profile-tab .text-danger {
        color: #ef4444 !important;
    }
    
    .profile-tab .text-gray-600 {
        color: #6b7280;
    }
    
    .profile-tab .alert {
        padding: 1rem;
        margin-bottom: 1rem;
        border: 1px solid transparent;
        border-radius: 0.375rem;
    }
    
    .profile-tab .alert-danger {
        background-color: #fef2f2;
        border-color: #fecaca;
        color: #dc2626;
    }
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- apexcharts-->
    <script src="<?php echo e(asset('assets/vendor/apexcharts/apexcharts.min.js')); ?>"></script>

    <!-- Glight js -->
    <script src="<?php echo e(asset('assets/vendor/glightbox/glightbox.min.js')); ?>"></script>

    <!-- sweetalert js-->
    <script src="<?php echo e(asset('assets/vendor/sweetalert/sweetalert.js')); ?>"></script>

    <!-- select2 -->
    <script src="<?php echo e(asset('assets/vendor/select/select2.min.js')); ?>"></script>

    <!--js-->
    <script src="<?php echo e(asset('assets/js/touchspin.js')); ?>"></script>

    <!--setting js  -->
    <script src="<?php echo e(asset('assets/js/setting.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/profile/edit.blade.php ENDPATH**/ ?>