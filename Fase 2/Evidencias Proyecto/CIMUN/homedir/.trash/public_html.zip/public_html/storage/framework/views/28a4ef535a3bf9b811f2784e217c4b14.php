<?php $__env->startSection('title', 'Rdialbar Chart'); ?>
<?php $__env->startSection('css'); ?>
    <!-- apexcharts css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/apexcharts/apexcharts.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <!-- Breadcrumb start -->
        <div class="row m-1">
            <div class="col-12 ">
                <h4 class="main-title">Radial Bar</h4>
                <ul class="app-line-breadcrumbs mb-3">
                    <li class="">
                        <a class="f-s-14 f-w-500" href="#">
                      <span>
                        <i class="ph-duotone  ph-chart-pie-slice f-s-16"></i> Chart
                      </span>
                        </a>
                    </li>
                    <li class="">
                        <a class="f-s-14 f-w-500" href="#">
                      <span>
                        Apexcharts
                      </span>
                        </a>
                    </li>
                    <li class="active">
                        <a class="f-s-14 f-w-500" href="#">Radialbar</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Breadcrumb end -->
        <!-- Chart start -->
        <div class="row">
            <div class="col-lg-6 col-xxl-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Basic RadialBar Chart</h5>
                    </div>
                    <div class="card-body">
                        <div id="radial-bar1"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-xxl-4">
                <div class="card">
                    <div class="card-header">
                        <h5> Multiple RadialBars</h5>
                    </div>
                    <div class="card-body ">
                        <div id="radial-bar2"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-xxl-4">
                <div class="card">
                    <div class="card-header">
                        <h5> Circle Chart – Custom Angle</h5>
                    </div>
                    <div class="card-body ">
                        <div id="radial-bar3"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-xxl-4">
                <div class="card equal-card">
                    <div class="card-header">
                        <h5> Stroked Circular Gauge</h5>
                    </div>
                    <div class="card-body ">
                        <div id="radial-bar5"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-xxl-4">
                <div class="card equal-card">
                    <div class="card-header">
                        <h5> Semi Circular Gauge</h5>
                    </div>
                    <div class="card-body ">
                        <div id="radial-bar6"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-xxl-4">
                <div class="card equal-card">
                    <div class="card-header">
                        <h5> Circle Chart with Image</h5>
                    </div>
                    <div class="card-body ">
                        <div id="radial-bar7"></div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Custom size and custom thickness</h5>
                        <p>You can use customize size by adding</p>
                    </div>
                    <div class="card-body">
                        <div class="d-flex flex-wrap custom-radial justify-content-center">
                            <div class="d-flex align-items-center flex-column">
                                <div class="mt-auto">
                                    <div id="radial-progress18"></div>
                                </div>
                                <div class="mt-auto">
                                    <p class=" text-primary f-s-18 f-w-600">Primary</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center flex-column">
                                <div class="mt-auto">
                                    <div id="radial-progress19"></div>
                                </div>
                                <div class="mt-auto">
                                    <p class=" text-secondary f-s-18 f-w-600 ">secondary</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center flex-column">
                                <div class="mt-auto">
                                    <div id="radial-progress20"></div>
                                </div>
                                <div class="mt-auto">
                                    <p class=" text-success f-s-18 f-w-600 ">Success</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center flex-column">
                                <div class="mt-auto">
                                    <div id="radial-progress21"></div>
                                </div>
                                <div class="mt-auto">
                                    <p class=" text-danger f-s-18 f-w-600 ">Danger</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center flex-column">
                                <div class="mt-auto">
                                    <div id="radial-progress22"></div>
                                </div>
                                <div class="mt-auto">
                                    <p class=" text-warning f-s-18 f-w-600 ">Warning</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center flex-column">
                                <div class="mt-auto">
                                    <div id="radial-progress23"></div>
                                </div>
                                <div class="mt-auto">
                                    <p class=" text-info f-s-18 f-w-600 ">Info</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center flex-column">
                                <div class="mt-auto">
                                    <div id="radial-progress24"></div>
                                </div>
                                <div class="mt-auto">
                                    <p class=" text-dark f-s-18 f-w-600 ">dark</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Chart end -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<!-- apexcharts-->
<script src="<?php echo e(asset('assets/vendor/apexcharts/apexcharts.min.js')); ?>"></script>

<!-- js-->
<script src="<?php echo e(asset('assets/js/radial_bar.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/radial_bar_chart.blade.php ENDPATH**/ ?>