<?php $__env->startSection('title', 'Cargos asignados a '.$user->name); ?>

<?php $__env->startSection('main-content'); ?>
<div class="container">
    <h2>Cargos asignados a <?php echo e($user->name); ?></h2>

    <?php if($user->positions->count()): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Cargo</th>
                    <th>Área</th>
                    <th>Asignado desde</th>
                    <th>Finalizado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $user->positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($position->name); ?></td>
                        <td><?php echo e($position->area->name ?? '—'); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($position->pivot->assigned_at)->format('d-m-Y')); ?></td>
                        <td>
                            <?php if($position->pivot->ended_at): ?>
                                <?php echo e(\Carbon\Carbon::parse($position->pivot->ended_at)->format('d-m-Y')); ?>

                            <?php else: ?>
                                <span class="text-muted">Activo</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form action="<?php echo e(route('positions.removeFromUser')); ?>" method="POST" onsubmit="return confirm('¿Remover este cargo?')">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                                <input type="hidden" name="position_id" value="<?php echo e($position->id); ?>">
                                <button class="btn btn-sm btn-danger">Remover</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-muted">Este usuario no tiene cargos asignados.</p>
    <?php endif; ?>

    <a href="<?php echo e(route('positions.assignToUserForm', ['user' => $user->id])); ?>" class="btn btn-primary">Asignar nuevo cargo</a>
    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">Volver al listado de usuarios</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/users/user_positions.blade.php ENDPATH**/ ?>