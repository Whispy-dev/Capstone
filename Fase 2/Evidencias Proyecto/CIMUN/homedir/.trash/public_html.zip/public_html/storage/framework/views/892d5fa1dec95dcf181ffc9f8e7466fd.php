
<?php $__env->startSection('title', 'Sistema de Incidencias Municipales'); ?>
<?php $__env->startSection('css'); ?>
    <!-- slick css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/slick/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/slick/slick-theme.css')); ?>">
    
    <!-- Data Table css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/datatable/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/datatable/datatable2/buttons.dataTables.min.css')); ?>">
    
    <!-- Select2 CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet">
    
    <!-- SweetAlert2 CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.7.32/sweetalert2.min.css" rel="stylesheet">
    
    <style>
        .priority-high { color: #dc3545 !important; font-weight: bold; }
        .priority-medium { color: #ffc107 !important; font-weight: bold; }
        .priority-low { color: #28a745 !important; font-weight: bold; }
        
        .status-open { 
            background-color: #007bff; 
            color: white; 
            padding: 0.25rem 0.5rem; 
            border-radius: 0.375rem; 
            font-size: 0.75rem;
        }
        .status-pending { 
            background-color: #ffc107; 
            color: #212529; 
            padding: 0.25rem 0.5rem; 
            border-radius: 0.375rem; 
            font-size: 0.75rem;
        }
        .status-closed { 
            background-color: #6c757d; 
            color: white; 
            padding: 0.25rem 0.5rem; 
            border-radius: 0.375rem; 
            font-size: 0.75rem;
        }
        
        .incident-card {
            transition: transform 0.2s;
        }
        
        .incident-card:hover {
            transform: translateY(-2px);
        }
        
        .stats-icon {
            width: 50px;
            height: 50px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        }

        .action-buttons {
            white-space: nowrap;
        }

        .action-buttons .btn {
            margin-right: 0.25rem;
            margin-bottom: 0.25rem;
        }

        #incidentsTable {
            font-size: 0.875rem;
        }

        .table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <!-- Breadcrumb start -->
        <div class="row m-1">
            <div class="col-12">
                <h4 class="main-title">Sistema de Incidencias Municipales</h4>
                <ul class="app-line-breadcrumbs mb-3">
                    <li>
                        <a href="<?php echo e(route('dashboard.index')); ?>" class="f-s-14 f-w-500">
                            <span><i class="ph-duotone ph-house f-s-16"></i> Dashboard</span>
                        </a>
                    </li>
                    <li class="active">
                        <a href="#" class="f-s-14 f-w-500">Incidencias</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Breadcrumb end -->
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>


        <!-- Statistics Cards -->
        <div class="row ticket-app mb-4">
            <div class="col-lg-3 col-sm-6">
                <div class="card incident-card bg-primary text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stats-icon bg-white bg-opacity-20">
                                    <i class="ph-bold ph-ticket f-s-25 text-white"></i>
                                </div>
                                <h6 class="mb-1">Total Incidencias</h6>
                                <h3 class="mb-0"><?php echo e($statistics['all_tickets'] ?? 0); ?></h3>
                                <small class="opacity-75">Total registradas</small>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-white text-primary">Total</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-sm-6">
                <div class="card incident-card bg-info text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stats-icon bg-white bg-opacity-20">
                                    <i class="ph-bold ph-folder-open f-s-25 text-white"></i>
                                </div>
                                <h6 class="mb-1">Abiertas</h6>
                                <h3 class="mb-0"><?php echo e($statistics['open_tickets'] ?? 0); ?></h3>
                                <small class="opacity-75">Sin asignar</small>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-white text-info">Nuevas</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-sm-6">
                <div class="card incident-card bg-warning text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stats-icon bg-white bg-opacity-20">
                                    <i class="ph-bold ph-clock-countdown f-s-25 text-white"></i>
                                </div>
                                <h6 class="mb-1">En Proceso</h6>
                                <h3 class="mb-0"><?php echo e($statistics['pending_tickets'] ?? 0); ?></h3>
                                <small class="opacity-75">En progreso</small>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-white text-warning">Activas</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-sm-6">
                <div class="card incident-card bg-success text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stats-icon bg-white bg-opacity-20">
                                    <i class="ph-bold ph-check-circle f-s-25 text-white"></i>
                                </div>
                                <h6 class="mb-1">Cerradas</h6>
                                <h3 class="mb-0"><?php echo e($statistics['closed_tickets'] ?? 0); ?></h3>
                                <small class="opacity-75">Completadas</small>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-white text-success">Resueltas</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Create Incident Card -->
            <div class="col-lg-6">
                <div class="card create-ticket-card h-100">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-sm-7">
                                <div class="ticket-create">
                                    <h5 class="mb-2">Gestión de Incidencias</h5>
                                    <p class="mb-4 text-secondary">
                                        Registra, asigna y da seguimiento a los incidentes municipales. 
                                        Coordina la respuesta entre departamentos y mantén informados a los ciudadanos.
                                    </p>
                                    <button type="button" class="btn btn-primary me-2" id="create_incident_btn" data-bs-toggle="modal" data-bs-target="#incidentModal">
                                        <i class="ph-duotone ph-plus me-1"></i>
                                        Nueva Incidencia
                                    </button>

                                    <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#bulkImportModal">
                                        <i class="ph-duotone ph-upload me-1"></i>
                                        Importar
                                    </button>
                                </div>
                            </div>
                            <div class="col-sm-5">
                                <img src="<?php echo e(asset('../assets/images/icons/ticket.png')); ?>" alt="" class="img-fluid w-100 d-block m-auto">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Stats -->
            <div class="col-lg-6">
                <div class="card h-100">
                    <div class="card-header">
                        <h5 class="mb-0">Resumen por Prioridad</h5>
                        <small class="text-muted">Distribución actual</small>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-4">
                                <div class="mb-3">
                                    <i class="ph-duotone ph-warning-circle f-s-30 text-danger mb-2"></i>
                                    <h4 class="mb-0 text-danger"><?php echo e($statistics['high_priority'] ?? 0); ?></h4>
                                    <small class="text-muted">Alta Prioridad</small>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="mb-3">
                                    <i class="ph-duotone ph-info f-s-30 text-warning mb-2"></i>
                                    <h4 class="mb-0 text-warning"><?php echo e($statistics['medium_priority'] ?? 0); ?></h4>
                                    <small class="text-muted">Media Prioridad</small>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="mb-3">
                                    <i class="ph-duotone ph-check-circle f-s-30 text-success mb-2"></i>
                                    <h4 class="mb-0 text-success"><?php echo e($statistics['low_priority'] ?? 0); ?></h4>
                                    <small class="text-muted">Baja Prioridad</small>
                                </div>
                            </div>
                        </div>
                        <div class="mt-3">
                            <div class="progress" style="height: 8px;">
                                <div class="progress-bar bg-danger" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 45%" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100"></div>
                                <div class="progress-bar bg-success" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters and Actions -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h5 class="mb-0">Listado de Incidencias</h5>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex gap-2 justify-content-md-end">
                                    <select class="form-select form-select-sm" id="statusFilter" style="width: auto;">
                                        <option value="">Todos los estados</option>
                                        <option value="open">Abierto</option>
                                        <option value="pending">En Proceso</option>
                                        <option value="closed">Cerrado</option>
                                    </select>
                                    <select class="form-select form-select-sm" id="priorityFilter" style="width: auto;">
                                        <option value="">Todas las prioridades</option>
                                        <option value="high">Alta</option>
                                        <option value="medium">Media</option>
                                        <option value="low">Baja</option>
                                    </select>
                                    <button class="btn btn-sm btn-outline-primary" id="exportBtn">
                                        <i class="ph-duotone ph-download me-1"></i>
                                        Exportar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body px-0">
                        <div class="table-responsive app-scroll app-datatable-default">
                            <table id="incidentsTable" class="table table-striped table-hover w-100">
                                <thead>
                                    <tr>
                                        <th style="width: 40px;">
                                            <div class="checkbox-wrapper">
                                                <label class="check-box m-0">
                                                    <input type="checkbox" id="select-all">
                                                    <span class="checkmark outline-secondary"></span>
                                                </label>
                                            </div>
                                        </th>
                                        <th style="width: 60px;">ID</th>
                                        <th style="width: 80px;">Usuario</th>
                                        <th style="width: 300px;">Título</th>
                                        <th style="width: 100px;">Estado</th>
                                        <th style="width: 90px;">Prioridad</th>
                                        <th style="width: 120px;">Creado</th>
                                        <th style="width: 120px;">Actualizado</th>
                                        <th style="width: 180px;">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $incidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incident): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="incident-<?php echo e($incident->id); ?>">
                                        <td>
                                            <div class="checkbox-wrapper">
                                                <label class="check-box m-0">
                                                    <input type="checkbox" value="<?php echo e($incident->id); ?>">
                                                    <span class="checkmark outline-secondary"></span>
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-light text-dark">#<?php echo e($incident->id); ?></span>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-sm me-2">
                                                    <div class="avatar-title bg-primary rounded-circle">
                                                        <?php echo e(strtoupper(substr($incident->user->name ?? 'U', 0, 1))); ?>

                                                    </div>
                                                </div>
                                                <div>
                                                    <h6 class="mb-0 f-s-14"><?php echo e($incident->user->name ?? 'Sin asignar'); ?></h6>
                                                    <small class="text-muted"><?php echo e($incident->user->email ?? ''); ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div>
                                                <h6 class="mb-1 f-s-14"><?php echo e(Str::limit($incident->title, 50)); ?></h6>
                                                <?php if($incident->description): ?>
                                                <small class="text-muted"><?php echo e(Str::limit($incident->description, 80)); ?></small>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge status-<?php echo e($incident->status); ?>">
                                                <?php switch($incident->status):
                                                    case ('open'): ?>
                                                        🔵 Abierto
                                                        <?php break; ?>
                                                    <?php case ('pending'): ?>
                                                        🟡 En Proceso
                                                        <?php break; ?>
                                                    <?php case ('closed'): ?>
                                                        ⚫ Cerrado
                                                        <?php break; ?>
                                                    <?php default: ?>
                                                        <?php echo e(ucfirst($incident->status)); ?>

                                                <?php endswitch; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="priority-<?php echo e($incident->priority); ?>">
                                                <?php switch($incident->priority):
                                                    case ('high'): ?>
                                                        🔴 Alta
                                                        <?php break; ?>
                                                    <?php case ('medium'): ?>
                                                        🟡 Media
                                                        <?php break; ?>
                                                    <?php case ('low'): ?>
                                                        🟢 Baja
                                                        <?php break; ?>
                                                    <?php default: ?>
                                                        <?php echo e(ucfirst($incident->priority)); ?>

                                                <?php endswitch; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?php echo e($incident->created_at ? $incident->created_at->format('d/m/Y H:i') : 'N/A'); ?>

                                            </small>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?php echo e($incident->updated_at ? $incident->updated_at->format('d/m/Y H:i') : 'N/A'); ?>

                                            </small>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="<?php echo e(route('incidents.show', $incident->id)); ?>" class="btn btn-sm btn-info" title="Ver detalles">
                                                    <i class="ph-duotone ph-eye"></i>
                                                </a>

                                                <button class="btn btn-sm btn-warning edit-incident" data-id="<?php echo e($incident->id); ?>" title="Editar">
                                                    <i class="ph-duotone ph-pencil"></i>
                                                </button>
                                                <button class="btn btn-sm btn-success change-status" data-id="<?php echo e($incident->id); ?>" data-status="<?php echo e($incident->status); ?>" title="Cambiar estado">
                                                    <i class="ph-duotone ph-arrows-clockwise"></i>
                                                </button>
                                                <button class="btn btn-sm btn-danger delete-incident" data-id="<?php echo e($incident->id); ?>" title="Eliminar">
                                                    <i class="ph-duotone ph-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal para crear/editar incidencia -->
    <div class="modal fade" id="incidentModal" tabindex="-1" aria-labelledby="incidentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h1 class="modal-title fs-5 text-white" id="incidentModalLabel">Nueva Incidencia</h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <form id="incidentForm">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-12">
                                <div class="mb-3">
                                    <label class="form-label">Título <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="title" id="title" placeholder="Describe brevemente la incidencia" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="mb-3">
                                    <label class="form-label">Descripción</label>
                                    <textarea class="form-control" name="description" id="description" rows="4" placeholder="Describe detalladamente la incidencia..."></textarea>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="priority" class="form-label">Prioridad <span class="text-danger">*</span></label>
                                    <select class="form-select" name="priority" id="priority" required>
                                        <option value="">Seleccionar Prioridad</option>
                                        <option value="low">🟢 Baja</option>
                                        <option value="medium" selected>🟡 Media</option>
                                        <option value="high">🔴 Alta</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="status" class="form-label">Estado <span class="text-danger">*</span></label>
                                    <select class="form-select" name="status" id="status" required>
                                        <option value="">Seleccionar Estado</option>
                                        <option value="open" selected>🔵 Abierto</option>
                                        <option value="pending">🟡 Pendiente</option>
                                        <option value="closed">⚫ Cerrado</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="ph-duotone ph-floppy-disk me-1"></i>
                            <span id="submitBtnText">Crear Incidencia</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal para importación masiva -->
    <div class="modal fade" id="bulkImportModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Importar Incidencias Masivamente</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Archivo CSV/Excel</label>
                        <input type="file" class="form-control" accept=".csv,.xlsx,.xls">
                    </div>
                    <div class="alert alert-info">
                        <small>
                            <strong>Formato requerido:</strong> Título, Descripción, Prioridad (low/medium/high), Estado (open/pending/closed)
                        </small>
                    </div>
                    <div class="text-center">
                        <a href="#" class="btn btn-outline-primary btn-sm">
                            <i class="ph-duotone ph-download me-1"></i>
                            Descargar Plantilla
                        </a>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary">Importar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de confirmación de eliminación -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body text-center py-4">
                    <div class="mb-3">
                        <i class="ph-duotone ph-warning-circle f-s-48 text-danger"></i>
                    </div>
                    <h5 class="text-danger">¿Eliminar Incidencia?</h5>
                    <p class="text-muted">Esta acción no se puede deshacer. La incidencia se eliminará permanentemente del sistema.</p>
                    <div class="mt-4">
                        <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-danger" id="confirmDelete">
                            <i class="ph-duotone ph-trash me-1"></i>
                            Sí, Eliminar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para cambio de estado rápido -->
    <div class="modal fade" id="statusModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Cambiar Estado de Incidencia</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="statusForm">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Nuevo Estado</label>
                            <select class="form-select" name="status" id="newStatus" required>
                                <option value="open">🔵 Abierto</option>
                                <option value="pending">🟡 En Proceso</option>
                                <option value="closed">⚫ Cerrado</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Comentario (Opcional)</label>
                            <textarea class="form-control" name="comment" rows="3" placeholder="Agrega un comentario sobre el cambio de estado..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Actualizar Estado</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- slick-file -->
    <script src="<?php echo e(asset('assets/vendor/slick/slick.min.js')); ?>"></script>
    
    <!-- data table js-->
    <script src="<?php echo e(asset('assets/vendor/datatable/jquery.dataTables.min.js')); ?>"></script>
    
    <!-- Select2 JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
    
    <!-- SweetAlert2 para notificaciones -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.7.32/sweetalert2.min.js"></script>

    <script>
    $(document).ready(function() {
        let currentIncidentId = null;
        
        // Inicializar DataTable
        let table = $('#incidentsTable').DataTable({
            responsive: true,
            pageLength: 25,
            order: [[1, 'desc']], // Ordenar por ID descendente
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/es-ES.json'
            },
            columnDefs: [
                { orderable: false, targets: [0, 8] }, // Deshabilitar ordenamiento en checkbox y acciones
                { className: "text-center", targets: [0, 1, 4, 5, 8] }
            ]
        });

        // Filtros
        $('#statusFilter').on('change', function() {
            table.column(4).search($(this).val()).draw();
        });

        $('#priorityFilter').on('change', function() {
            table.column(5).search($(this).val()).draw();
        });
    
        // Crear incidencia
        $('#create_incident_btn').on('click', function() {
            $('#incidentModalLabel').text('Nueva Incidencia Municipal');
            $('#submitBtnText').text('Crear Incidencia');
            $('#incidentForm')[0].reset();
            $('#priority').val('medium');
            $('#status').val('open');
            currentIncidentId = null;
            enableIncidentForm();
        });
    
        // Envío del formulario
        $('#incidentForm').on('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const url = currentIncidentId 
                ? `<?php echo e(url('/incidencias')); ?>/${currentIncidentId}` 
                : '<?php echo e(route("incidents.store")); ?>';
    
            if (currentIncidentId) formData.append('_method', 'PUT');
    
            const submitBtn = $(this).find('button[type="submit"]');
            const originalText = submitBtn.html();
            submitBtn.html('<i class="ph-duotone ph-circle-notch ph-spin me-1"></i> Guardando...').prop('disabled', true);
    
            $.ajax({
                url: url,
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    $('#incidentModal').modal('hide');
                    const incident = response.data;
    
                    if (currentIncidentId) {
                        // Actualizar fila existente
                        table.row($(`#incident-${incident.id}`)).remove().draw();
                        table.row.add($(generateRowHTML(incident))).draw();
                    } else {
                        // Agregar nueva fila
                        table.row.add($(generateRowHTML(incident))).draw();
                    }
    
                    Swal.fire({ 
                        title: '¡Éxito!', 
                        text: response.message, 
                        icon: 'success', 
                        timer: 3000, 
                        showConfirmButton: false 
                    });
                },
                error: function(xhr) {
                    if (xhr.status === 422) {
                        const errors = xhr.responseJSON?.errors;
                        if (errors) {
                            let errorMessage = '';
                            Object.keys(errors).forEach(key => errorMessage += errors[key][0] + '\n');
                            Swal.fire({ title: 'Error de Validación', text: errorMessage, icon: 'error' });
                        }
                    } else {
                        Swal.fire({ title: 'Error', text: 'Ocurrió un error inesperado.', icon: 'error' });
                    }
                },
                complete: function() {
                    submitBtn.html(originalText).prop('disabled', false);
                }
            });
        });
    
        // Ver incidencia
        $(document).on('click', '.view-incident', function() {
            const id = $(this).data('id');
            $.get(`<?php echo e(url('/incidencias')); ?>/${id}`, function(response) {
                const incident = response.data;
                fillIncidentForm(incident, true);
                $('#incidentModalLabel').text('Ver Incidencia #' + incident.id);
                $('#submitBtnText').text('Cerrar');
                $('#incidentModal').modal('show');
            }).fail(function() {
                Swal.fire({ title: 'Error', text: 'No se pudo cargar la incidencia', icon: 'error' });
            });
        });
    
        // Editar incidencia
        $(document).on('click', '.edit-incident', function() {
            const id = $(this).data('id');
            $.get(`<?php echo e(url('/incidencias')); ?>/${id}`, function(response) {
                const incident = response.data;
                fillIncidentForm(incident, false);
                $('#incidentModalLabel').text('Editar Incidencia #' + incident.id);
                $('#submitBtnText').text('Actualizar Incidencia');
                $('#incidentModal').modal('show');
                currentIncidentId = incident.id;
            }).fail(function() {
                Swal.fire({ title: 'Error', text: 'No se pudo cargar la incidencia', icon: 'error' });
            });
        });
    
        // Eliminar incidencia
        $(document).on('click', '.delete-incident', function() {
            currentIncidentId = $(this).data('id');
            $('#deleteModal').modal('show');
        });
    
        $('#confirmDelete').on('click', function() {
            const btn = $(this);
            const originalText = btn.html();
            btn.html('<i class="ph-duotone ph-circle-notch ph-spin me-1"></i> Eliminando...').prop('disabled', true);
    
            $.ajax({
                url: `<?php echo e(url('/incidencias')); ?>/${currentIncidentId}`,
                method: 'DELETE',
                data: { _token: '<?php echo e(csrf_token()); ?>' },
                success: function(response) {
                    $('#deleteModal').modal('hide');
                    table.row($(`#incident-${currentIncidentId}`)).remove().draw();
                    Swal.fire({ 
                        title: 'Eliminado', 
                        text: response.message, 
                        icon: 'success', 
                        timer: 2000, 
                        showConfirmButton: false 
                    });
                },
                error: function() {
                    Swal.fire({ title: 'Error', text: 'No se pudo eliminar la incidencia', icon: 'error' });
                },
                complete: function() {
                    btn.html(originalText).prop('disabled', false);
                }
            });
        });
    
        // Cambio rápido de estado
        $(document).on('click', '.change-status', function() {
            currentIncidentId = $(this).data('id');
            $('#newStatus').val($(this).data('status'));
            $('#statusModal').modal('show');
        });
    
        $('#statusForm').on('submit', function(e) {
            e.preventDefault();
            const btn = $(this).find('button[type="submit"]');
            const originalText = btn.html();
            btn.html('<i class="ph-duotone ph-circle-notch ph-spin me-1"></i> Actualizando...').prop('disabled', true);
    
            $.ajax({
                url: `<?php echo e(url('/incidencias')); ?>/${currentIncidentId}/status`,
                method: 'PATCH',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    status: $('#newStatus').val(),
                    comment: $('textarea[name="comment"]').val()
                },
                success: function(response) {
                    $('#statusModal').modal('hide');
                    
                    // Recargar la fila actualizada
                    $.get(`<?php echo e(url('/incidencias')); ?>/${currentIncidentId}`, function(incidentResponse) {
                        const incident = incidentResponse.data;
                        table.row($(`#incident-${currentIncidentId}`)).remove().draw();
                        table.row.add($(generateRowHTML(incident))).draw();
                    });
                    
                    Swal.fire({ 
                        title: 'Estado Actualizado', 
                        text: response.message, 
                        icon: 'success', 
                        timer: 2000, 
                        showConfirmButton: false 
                    });
                    $('#statusForm')[0].reset();
                },
                error: function() {
                    Swal.fire({ title: 'Error', text: 'No se pudo actualizar el estado', icon: 'error' });
                },
                complete: function() {
                    btn.html(originalText).prop('disabled', false);
                }
            });
        });
    
        // Exportar datos
        $('#exportBtn').on('click', function() {
            const btn = $(this);
            const originalText = btn.html();
            btn.html('<i class="ph-duotone ph-circle-notch ph-spin me-1"></i> Exportando...').prop('disabled', true);
            
            setTimeout(() => {
                window.location.href = '<?php echo e(route("incidents.export")); ?>';
                btn.html(originalText).prop('disabled', false);
            }, 1000);
        });
    
        // Select all checkboxes
        $('#select-all').on('change', function() {
            const isChecked = $(this).is(':checked');
            $('#incidentsTable tbody input[type="checkbox"]').prop('checked', isChecked);
        });

        // Individual checkbox change
        $(document).on('change', '#incidentsTable tbody input[type="checkbox"]', function() {
            const totalCheckboxes = $('#incidentsTable tbody input[type="checkbox"]').length;
            const checkedCheckboxes = $('#incidentsTable tbody input[type="checkbox"]:checked').length;
            
            $('#select-all').prop('checked', totalCheckboxes === checkedCheckboxes);
        });
    
        // Funciones auxiliares
        function fillIncidentForm(incident, readOnly = false) {
            $('#title').val(incident.title).prop('readonly', readOnly);
            $('#description').val(incident.description || '').prop('readonly', readOnly);
            $('#priority').val(incident.priority).prop('disabled', readOnly);
            $('#status').val(incident.status).prop('disabled', readOnly);
            
            if (readOnly) {
                $('#incidentForm button[type="submit"]').hide();
            } else {
                $('#incidentForm button[type="submit"]').show();
            }
        }
    
        function enableIncidentForm() {
            $('#title, #description').prop('readonly', false);
            $('#priority, #status').prop('disabled', false);
            $('#incidentForm button[type="submit"]').show();
        }
    
        function generateRowHTML(incident) {
            const statusBadge = getStatusBadge(incident.status);
            const priorityText = getPriorityText(incident.priority);
            const userName = incident.user ? incident.user.name : 'Sin asignar';
            const userEmail = incident.user ? incident.user.email : '';
            const userInitial = userName.charAt(0).toUpperCase();
            
            return `
                <tr id="incident-${incident.id}">
                    <td>
                        <div class="checkbox-wrapper">
                            <label class="check-box m-0">
                                <input type="checkbox" value="${incident.id}">
                                <span class="checkmark outline-secondary"></span>
                            </label>
                        </div>
                    </td>
                    <td>
                        <span class="badge bg-light text-dark">#${incident.id}</span>
                    </td>
                    <td>
                        <div class="d-flex align-items-center">
                            <div class="avatar-sm me-2">
                                <div class="avatar-title bg-primary rounded-circle">
                                    ${userInitial}
                                </div>
                            </div>
                            <div>
                                <h6 class="mb-0 f-s-14">${userName}</h6>
                                <small class="text-muted">${userEmail}</small>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div>
                            <h6 class="mb-1 f-s-14">${incident.title.length > 50 ? incident.title.substring(0, 50) + '...' : incident.title}</h6>
                            ${incident.description ? `<small class="text-muted">${incident.description.length > 80 ? incident.description.substring(0, 80) + '...' : incident.description}</small>` : ''}
                        </div>
                    </td>
                    <td>
                        <span class="badge status-${incident.status}">
                            ${statusBadge}
                        </span>
                    </td>
                    <td>
                        <span class="priority-${incident.priority}">
                            ${priorityText}
                        </span>
                    </td>
                    <td>
                        <small class="text-muted">
                            ${incident.created_at ? new Date(incident.created_at).toLocaleDateString('es-ES') + ' ' + new Date(incident.created_at).toLocaleTimeString('es-ES', {hour: '2-digit', minute:'2-digit'}) : 'N/A'}
                        </small>
                    </td>
                    <td>
                        <small class="text-muted">
                            ${incident.updated_at ? new Date(incident.updated_at).toLocaleDateString('es-ES') + ' ' + new Date(incident.updated_at).toLocaleTimeString('es-ES', {hour: '2-digit', minute:'2-digit'}) : 'N/A'}
                        </small>
                    </td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn btn-sm btn-info view-incident" data-id="${incident.id}" title="Ver detalles">
                                <i class="ph-duotone ph-eye"></i>
                            </button>
                            <button class="btn btn-sm btn-warning edit-incident" data-id="${incident.id}" title="Editar">
                                <i class="ph-duotone ph-pencil"></i>
                            </button>
                            <button class="btn btn-sm btn-success change-status" data-id="${incident.id}" data-status="${incident.status}" title="Cambiar estado">
                                <i class="ph-duotone ph-arrows-clockwise"></i>
                            </button>
                            <button class="btn btn-sm btn-danger delete-incident" data-id="${incident.id}" title="Eliminar">
                                <i class="ph-duotone ph-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }
        
        function getStatusBadge(status) {
            switch(status) {
                case 'open':
                    return '🔵 Abierto';
                case 'pending':
                    return '🟡 En Proceso';
                case 'closed':
                    return '⚫ Cerrado';
                default:
                    return status.charAt(0).toUpperCase() + status.slice(1);
            }
        }
        
        function getPriorityText(priority) {
            switch(priority) {
                case 'high':
                    return '🔴 Alta';
                case 'medium':
                    return '🟡 Media';
                case 'low':
                    return '🟢 Baja';
                default:
                    return priority.charAt(0).toUpperCase() + priority.slice(1);
            }
        }
    });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/incidents/index.blade.php ENDPATH**/ ?>