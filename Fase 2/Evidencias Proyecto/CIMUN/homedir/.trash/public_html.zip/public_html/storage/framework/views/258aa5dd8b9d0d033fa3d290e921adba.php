<?php $__env->startSection('title', 'Editar Cargo'); ?>

<?php $__env->startSection('main-content'); ?>
<div class="container">
    <h2>Editar Cargo</h2>

    <form action="<?php echo e(route('positions.update', $position->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="name" class="form-label">Nombre del Cargo</label>
            <input type="text" name="name" class="form-control" required value="<?php echo e(old('name', $position->name)); ?>">
        </div>

        <div class="mb-3">
            <label for="level" class="form-label">Nivel</label>
            <input type="text" name="level" class="form-control" value="<?php echo e(old('level', $position->level)); ?>">
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Descripción</label>
            <textarea name="description" class="form-control"><?php echo e(old('description', $position->description)); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="area_id" class="form-label">Área Asociada</label>
            <select name="area_id" class="form-select" required>
                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($area->id); ?>" <?php echo e($position->area_id == $area->id ? 'selected' : ''); ?>>
                        <?php echo e($area->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button type="submit" class="btn btn-success">Actualizar</button>
        <a href="<?php echo e(route('positions.index')); ?>" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/positions/edit.blade.php ENDPATH**/ ?>