<!-- latest jquery-->
<script src="<?php echo e(asset('assets/js/jquery-3.6.3.min.js')); ?>"></script>

<!-- Bootstrap js-->
<script src="<?php echo e(asset('assets/vendor/bootstrap/bootstrap.bundle.min.js')); ?>"></script>

<!-- Simple bar js-->
<script src="<?php echo e(asset('assets/vendor/simplebar/simplebar.js')); ?>"></script>

<!-- phosphor js -->
<script src="<?php echo e(asset('assets/vendor/phosphor/phosphor.js')); ?>"></script>

<!-- Customizer js-->
<script src="<?php echo e(asset('assets/js/customizer.js')); ?>"></script>

<!-- prism js-->
<script src="<?php echo e(asset('assets/vendor/prism/prism.min.js')); ?>"></script>

<!-- App js-->
<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

<?php echo $__env->yieldContent('script'); ?>
<?php /**PATH /home/cimun/public_html/resources/views/layout/script.blade.php ENDPATH**/ ?>