<?php $__env->startSection('title', 'Detalles del Incidente'); ?>

<?php $__env->startSection('main-content'); ?>
<div class="container">
    <h2>Detalle del Cargo</h2>

    <div class="card mb-4">
        <div class="card-body">
            <h4 class="card-title"><?php echo e($position->name); ?></h4>
            <p class="card-text"><strong>Nivel:</strong> <?php echo e($position->level ?? '—'); ?></p>
            <p class="card-text"><strong>Área:</strong> <?php echo e($position->area->name ?? 'Sin área asignada'); ?></p>
            <p class="card-text"><strong>Descripción:</strong> <?php echo e($position->description ?? '—'); ?></p>
        </div>
    </div>

    <h5>Usuarios Asignados</h5>
    <?php if($position->users->count()): ?>
        <ul class="list-group mb-4">
            <?php $__currentLoopData = $position->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <strong><?php echo e($user->name); ?></strong> <small class="text-muted">(<?php echo e($user->email); ?>)</small>
                    </div>
                    <div>
                        <?php if($user->pivot->assigned_at): ?>
                            <span class="badge bg-primary">Asignado: <?php echo e(\Carbon\Carbon::parse($user->pivot->assigned_at)->format('d-m-Y')); ?></span>
                        <?php endif; ?>
                        <?php if($user->pivot->ended_at): ?>
                            <span class="badge bg-secondary">Finalizado: <?php echo e(\Carbon\Carbon::parse($user->pivot->ended_at)->format('d-m-Y')); ?></span>
                        <?php endif; ?>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <p class="text-muted">No hay usuarios asignados a este cargo.</p>
    <?php endif; ?>

    <a href="<?php echo e(route('positions.edit', $position->id)); ?>" class="btn btn-warning">Editar</a>
    <a href="<?php echo e(route('positions.index')); ?>" class="btn btn-secondary">Volver al listado</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/positions/show.blade.php ENDPATH**/ ?>