<?php $__env->startSection('title', 'Detalles del Incidente'); ?>

<?php $__env->startSection('main-content'); ?>
<div class="container">
    <h2 class="mb-4">Listado de Cargos</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('positions.create')); ?>" class="btn btn-primary mb-3">Crear Nuevo Cargo</a>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Nivel</th>
                <th>Área</th>
                <th>Usuarios Asignados</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($position->name); ?></td>
                    <td><?php echo e($position->level ?? '—'); ?></td>
                    <td><?php echo e($position->area->name ?? 'Sin área'); ?></td>
                    <td>
                        <?php if($position->users->count()): ?>
                            <ul class="list-unstyled mb-0">
                                <?php $__currentLoopData = $position->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($user->name); ?> <small class="text-muted">(<?php echo e($user->email); ?>)</small></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <span class="text-muted">Sin asignaciones</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('positions.show', $position->id)); ?>" class="btn btn-sm btn-info">Ver</a>
                        <a href="<?php echo e(route('positions.edit', $position->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                        <form action="<?php echo e(route('positions.destroy', $position->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar este cargo?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center text-muted">No hay cargos registrados.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/positions/index.blade.php ENDPATH**/ ?>