<?php $__env->startSection('title', 'Editor'); ?>
<?php $__env->startSection('css'); ?>
    <!-- editor css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/trumbowyg/trumbowyg.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <!-- Breadcrumb start -->
        <div class="row m-1">
            <div class="col-12 ">
                <h4 class="main-title">Editor</h4>
                <ul class="app-line-breadcrumbs mb-3">
                    <li class="">
                        <a href="#" class="f-s-14 f-w-500">
									<span>
									  <i class="ph-duotone  ph-briefcase f-s-16"></i> Ui kits
									</span>
                        </a>
                    </li>
                    <li class="active">
                        <a href="#" class="f-s-14 f-w-500">Editor</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Breadcrumb end -->

        <!-- Editor start -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="app-editor" id="editor">
                            <p>Hello !</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div id="editor1">
                            <p>Hello !</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Editor end -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>



<!-- Trumbowyg js -->
<script src="<?php echo e(asset('assets/vendor/trumbowyg/trumbowyg.min.js')); ?>"></script>

<!-- js -->
<script src="<?php echo e(asset('assets/js/editor.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cimun/public_html/resources/views/editor.blade.php ENDPATH**/ ?>