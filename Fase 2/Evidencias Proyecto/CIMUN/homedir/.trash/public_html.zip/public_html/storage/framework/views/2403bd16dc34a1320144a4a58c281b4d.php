<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <?php echo $__env->make('layout.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('layout.css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- phosphor-icon css-->
    <link href="<?php echo e(asset('../assets/vendor/phosphor/phosphor-bold.css')); ?>" rel="stylesheet">
</head>

<body class="sign-in-bg">
    <div class="app-wrapper d-block">
        <div class="container main-container">
            <div class="row main-content-box">
                
                <!-- Sección de imagen (solo visible en pantallas grandes) -->
                <div class="col-lg-7 image-content-box d-none d-lg-block">
                    <div class="form-container">
                        <div class="signup-content mt-4">
                            <span>
                                <img alt="Logo" class="img-fluid" src="../assets/images/logo/LOGOCIMUN.png">
                            </span>
                        </div>
                        <div class="signup-bg-img">
                            <img alt="Imagen de login" class="img-fluid" src="../assets/images/login/01.png">
                        </div>
                    </div>
                </div>

                <!-- Sección del formulario -->
                <div class="col-lg-5 form-content-box">
                    <div class="form-container">
                        <form method="POST" class="app-form" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                
                                <!-- Título de bienvenida -->
                                <div class="col-12">
                                    <div class="mb-5 text-center text-lg-start">
                                        <h2 class="text-white f-w-600">
                                            ¡Bienvenido a <span class="text-dark">CI-MUN!</span>
                                        </h2>
                                        <p class="f-s-16 mt-2">
                                            Inicia sesión con los datos que ingresaste durante tu registro
                                        </p>
                                    </div>
                                </div>

                                <!-- Campo de Email -->
                                <div class="col-12">
                                    <div class="form-floating mb-3">
                                        <input 
                                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="email" 
                                            name="email"
                                            placeholder="Ingrese su correo electrónico"
                                            type="email" 
                                            value="<?php echo e(old('email')); ?>"
                                            required 
                                            autofocus 
                                            autocomplete="username"
                                        >
                                        <label for="email">Correo Electrónico</label>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <!-- Campo de Contraseña -->
                                <div class="col-12">
                                    <div class="form-floating mb-3">
                                        <input 
                                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="password" 
                                            name="password"
                                            placeholder="Ingrese su contraseña"
                                            type="password"
                                            required 
                                            autocomplete="current-password"
                                        >
                                        <label for="password">Contraseña</label>
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                    <!-- Enlace de contraseña olvidada -->
                                    <div class="text-end">
                                        <?php if(Route::has('password.request')): ?>
                                            <a class="text-dark f-w-500 text-decoration-underline" 
                                               href="<?php echo e(route('password.request')); ?>">
                                                ¿Olvidaste tu contraseña?
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Checkbox Recordarme -->
                                <div class="col-12">
                                    <div class="form-check d-flex align-items-center gap-2 mb-3">
                                        <input 
                                            class="form-check-input w-25 h-25" 
                                            id="remember_me" 
                                            name="remember"
                                            type="checkbox"
                                        >
                                        <label class="form-check-label text-dark f-s-16" for="remember_me">
                                            Recordarme
                                        </label>
                                    </div>
                                </div>

                                <!-- Botón de inicio de sesión -->
                                <div class="col-12 mt-3">
                                    <button class="btn btn-primary btn-lg w-100" type="submit">
                                        Iniciar Sesión
                                    </button>
                                </div>

                                <!-- Enlace de registro -->
                                <div class="col-12 mt-4">
                                    <div class="text-center text-lg-start f-w-500">
                                        ¿Aún no tienes una cuenta?
                                        <a class="text-white-800 text-decoration-underline" 
                                           href="<?php echo e(route('register')); ?>">
                                            Regístrate
                                        </a>
                                    </div>
                                </div>

                                <!-- Divisor -->
                                <div class="app-divider-v light justify-content-center py-lg-5 py-3 d-none">
                                    <p>O</p>
                                </div>

                                <!-- Botones de redes sociales -->
                                <div class="col-12 d-none">
                                    <div class="d-flex gap-3 justify-content-center text-center">
                                        <button class="btn btn-light-white icon-btn w-45 h-45 b-r-15" 
                                                type="button" 
                                                title="Iniciar sesión con Facebook">
                                            <i class="ph-bold ph-facebook-logo f-s-20"></i>
                                        </button>
                                        <button class="btn btn-light-white icon-btn w-45 h-45 b-r-15" 
                                                type="button" 
                                                title="Iniciar sesión con Google">
                                            <i class="ph-bold ph-google-logo f-s-20"></i>
                                        </button>
                                        <button class="btn btn-light-white icon-btn w-45 h-45 b-r-15" 
                                                type="button" 
                                                title="Iniciar sesión con Twitter">
                                            <i class="ph-bold ph-twitter-logo f-s-20"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            
            </div>
        </div>
    </div>

    <!-- Bootstrap JavaScript -->
    <script src="<?php echo e(asset('assets/vendor/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/cimun/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>