<?php

declare(strict_types=1);

namespace CuyZ\Valinor\Type\Parser\Exception;

use Throwable;

/** @internal */
interface InvalidType extends Throwable {}
