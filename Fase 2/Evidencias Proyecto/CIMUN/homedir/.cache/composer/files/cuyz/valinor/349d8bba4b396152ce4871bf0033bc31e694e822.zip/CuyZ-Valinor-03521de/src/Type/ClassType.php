<?php

declare(strict_types=1);

namespace CuyZ\Valinor\Type;

/** @internal */
interface ClassType extends ObjectType {}
